package com.mindex.challenge.service.impl;

import com.mindex.challenge.dao.EmployeeRepository;
import com.mindex.challenge.data.Employee;
import com.mindex.challenge.data.ReportingStructure;
import com.mindex.challenge.service.ReportingStructureService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReportingStructureServiceImpl implements ReportingStructureService {

    private static final Logger LOG = LoggerFactory.getLogger(ReportingStructureServiceImpl.class);

    @Autowired
    private EmployeeRepository employeeRepository;

    @Override
    public ReportingStructure getReportingStructure(String employeeId) {
        LOG.debug("Get ReportingStructure Employee [{}]", employeeId);
        ReportingStructure reportingStructure = new ReportingStructure();
        int directReports = 0;
        Employee employee = employeeRepository.findByEmployeeId(employeeId);

        if (employee == null) {
            throw new RuntimeException("Invalid employeeId: " + employeeId);
        }
        reportingStructure.setEmployee(employee);
        List<Employee> allEmployees = employee.getDirectReports();
        while(allEmployees!=null && !allEmployees.isEmpty()){
            String id = allEmployees.remove(allEmployees.size() - 1).getEmployeeId();
            Employee e = employeeRepository.findByEmployeeId(id);
            if(e.getDirectReports()!=null && !e.getDirectReports().isEmpty())
                allEmployees.addAll(e.getDirectReports());
            ++directReports;
        }
        reportingStructure.setNumberOfReports(directReports);
        return reportingStructure;
    }
}
