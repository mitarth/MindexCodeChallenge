package com.mindex.challenge.data;


import java.time.LocalDate;

public class Compensation {
    private String employeeId;
    private Double salary;
    private LocalDate effectiveDate;

    public Compensation() {
    }

    public Double getSalary() {
        return salary;
    }

    public void setSalary(Double salary) {
        this.salary = salary;
    }

    public LocalDate getEffectiveDate() {
        return effectiveDate;
    }

    public void setEffectiveDate(LocalDate effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    public String getId() {
        return employeeId;
    }

    public void setId(String id) {
        this.employeeId = id;
    }
}
